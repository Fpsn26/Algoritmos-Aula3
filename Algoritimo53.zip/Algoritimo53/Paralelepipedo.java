package Algoritimo53;
public class Paralelepipedo {
    double dA;
    double dB;
    double dC;
    double dDiagonal;
}
